This extension will claim your bonus on Twitch while you are enjoying the stream.

This extension does not collect or store any of your data. 

Google Web Store Link : https://chrome.google.com/webstore/detail/twitch-auto-bonus-claimer/ddhkokekpijdobdjhlbldojfglknhjgp?hl=tr&authuser=0
